<?php $__env->startSection('content'); ?>
    <div id="UserPastes" style="display: block;">
        <div class="default_text_and_line_below">
            Ваши пасты:
        </div>
        <div style="width: 50%; float: left; margin: 10px;">
            <table>
                <thead>
                    <tr>
                        <th scope="col">Номер</th>
                        <th scope="col">Заголовок</th>
                        <th scope="col">Идентификатор</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user_pastes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($paste->title); ?></td>
                            <td><a href="http://127.0.0.1:8000/paste/<?php echo e($paste->identify); ?>"><?php echo e($paste->identify); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($user_pastes->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Baren\Downloads\OSPanel\domains\pastebinbarenad\resources\views/my_pastes.blade.php ENDPATH**/ ?>