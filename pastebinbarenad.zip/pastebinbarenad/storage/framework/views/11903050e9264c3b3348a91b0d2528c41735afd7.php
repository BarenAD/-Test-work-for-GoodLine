<div class="Header_area">
    <div class="Header_container_area">
        <a href="/">
            <div class="logo_analog_pastebin">
                PASTEBIN
                <br>
                BY BARENAD
            </div>
        </a>
        <a href="/new_paste"> <input type="button" value="+ New paste" class="Button_New_Paste"> </a>
        <div class="search_div">
            <input type="text" placeholder="поиск...">
            <img src="/img/search.png" onclick="search()">
        </div>
        <div class="login_list">

            <ul id="menu_list_ghost" class="login_sublist"">
                <li><a href="/register">Зарегистрироваться</a></li>
                <li><a href="/home">Войти</a></li>
            </ul>


            <ul id="menu_list_users" class="login_sublist">
                <li><a href="">Мои настройки</a></li>
                <li><a href="">Мои оповещения</a></li>
                <li><a href="">Мои сообщения</a></li>
                <li><a href="">Мои пасты</a></li>
                <li><a href="">Выйти</a></li>
            </ul>

        </div>
        <img id="avatar" class="avatar" src="/img/guest.png">
        <UserName id="UserName" class="UserName">Guest User</UserName>
        <!--
        <img id="my_settings" class="my_profile_icons" src="/img/my_settings.png" title="Мои настройки" onclick="open_menu_my_settings()">
        <img id="my_alerts" class="my_profile_icons" src="/img/my_alerts.png" title="Мои оповещения" onclick="open_menu_my_alerts()">
        <img id="my_messages" class="my_profile_icons" src="/img/my_messages.png" title="Мои сообщения" onclick="open_menu_my_messages()">
        <img id="my_pastes" class="my_profile_icons" src="/img/my_pastes.png" title="Мои пасты" onclick="open_menu_my_pastes()">
        -->
    </div>
</div><?php /**PATH C:\Users\Baren\Downloads\OSPanel\domains\pastebinbarenad\resources\views/layouts/navigator.blade.php ENDPATH**/ ?>