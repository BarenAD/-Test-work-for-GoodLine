<html lang="ru">

<head>
    <meta charset="utf-8">
    <title>Pastebin от BARENAD</title>
    <link href="css/style.css" rel="stylesheet">
	<link href="css/login_list.css" rel="stylesheet">
	<link rel="shortcut icon" href="favicon.ico?ver=2.3.0" type="image/x-icon">
	<script src="js/model.js"></script>
	<script src="js/main.js"></script>

</head>

<body>
	<script>
		var Pastes = JSON.parse('<?php echo $pastes;?>');
	</script>
	<div class="my_MAIN_area">
		<? include('patterns/header.php'); ?>
		<div class="Basic_area">
			<div id="ContentArea" class="ContentArea">
				<div id="NewPaste">
					<div class="default_text" style="margin: 10px 0 0 5%;">
						Новая паста
					</div>
					<textarea id="TextReaderPaste" class="TextReaderPaste"></textarea>
					<div class="default_text_and_line_below">
						Дополнительные параметры пасты
					</div>
					<div style="width: 50%; float: left; margin: 10px;">
						<div class="LineFrameOptionalPasteSettings">
							<text>Время жизни:</text>
							<select id="SelectTimeLifePaste">
								<option selected value=0>Бесконечно</option>
								<option value=0.006944>10 минут</option>
								<option value=0.0416>1 час</option>
								<option value=7>1 неделя</option>
								<option value=14>2 недели</option>
								<option value=30>1 месяц</option>
								<option value=365>1 год</option>
							</select>
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text>Доступ:</text>
							<select id="SelectAccessPaste">
								<option selected value="PUBLIC">Публично</option>
								<option value="LINK">По ссылке</option>
							</select>
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text>Заголовок пасты:</text>
							<input id="SelectTitlePaste" type="text" placeholder="название">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text style="width: 30%;">Анонимно:</text>
							<input type="checkbox" id="SelectAnonymousPaste" style="width: 20%; float: left;">
							<script>
								if (!checked_authorization())
								{
									document.getElementById('SelectAnonymousPaste').disabled = true;
									document.getElementById('SelectAnonymousPaste').checked = true;
								}
							</script>
							<input type="button" value="создать пасту" onclick="create_paste()">
						</div>
					</div>
					<div> </div>
				</div>
				<div id="Login" style="display:none;">
					<div class="default_text_and_line_below">
						Авторизация
					</div>
					<div style="width: 50%; float: left; margin: 10px;">
						<div class="LineFrameOptionalPasteSettings">
							<text>Логин</text>
							<input id="AuthorizationInputLogin" type="text" placeholder="логин">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text>Пароль</text>
							<input id="AuthorizationInputPassword" type="password" placeholder="пароль">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<input type="button" value="войти" onclick="authorization()">
						</div>
					</div>
				</div>
				<div id="Registration" style="display:none;">
					<div class="default_text_and_line_below">
						Регистрация
					</div>
					<div style="width: 50%; float: left; margin: 10px;">
						<div class="LineFrameOptionalPasteSettings">
							<text>Логин</text>
							<input id="RegistrationInputLogin" type="text" placeholder="логин">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text>Почта</text>
							<input id="RegistrationInputMail" type="text" placeholder="почта">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text>Пароль</text>
							<input id="RegistrationInputPassword" type="password" placeholder="пароль">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<text>Подтверждение пароля</text>
							<input id="RegistrationInputPassword2" type="password" placeholder="повторите пароль">
						</div>
						<div class="LineFrameOptionalPasteSettings">
							<input type="button" value="зарегистрироваться" onclick="registration()">
						</div>
					</div>
				</div>
			</div>
			<div id="Right_Bar" class="Right_Bar_area"></div>
		</div>
	</div>

</body>

</html><?php /**PATH C:\Users\Baren\Downloads\OSPanel\domains\pastebinbarenad\resources\views/index.blade.php ENDPATH**/ ?>