<?php $__env->startSection('content'); ?>
    <div id="ShowPaste" style="display: block;">
        <div class="default_text" style="margin: 10px 0 0 5%;">
            <?php echo e($paste->title); ?>

        </div>
        <textarea id="TextReaderPaste" class="TextReaderPaste"><?php echo e($paste->paste); ?></textarea>
        <div class="default_text_and_line_below">
            Дополнительные параметры пасты
        </div>
        <div style="width: 50%; float: left; margin: 10px;">
            <div class="LineFrameOptionalPasteSettings">
                <text>Автор:</text>
                <text><?php echo e($paste->author); ?></text>
            </div>
            <div class="LineFrameOptionalPasteSettings">
                <text>Дата создания</text>
                <text><?php echo e($paste->created_at); ?></text>
            </div>
            <div class="LineFrameOptionalPasteSettings">
                <text>Текущая дата</text>
                <text><?php echo e($current_date); ?></text>
            </div>
            <div class="LineFrameOptionalPasteSettings">
                <text>Дата удаления</text>
                <text><?php echo e($paste->end_at); ?></text>
            </div>
            <div class="LineFrameOptionalPasteSettings">
                <text>Доступ:</text>
                <text><?php echo e($paste->acess); ?></text>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Baren\Downloads\OSPanel\domains\pastebinbarenad\resources\views/show_paste.blade.php ENDPATH**/ ?>