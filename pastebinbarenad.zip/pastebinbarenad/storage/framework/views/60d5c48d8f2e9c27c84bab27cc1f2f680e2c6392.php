<?php $__env->startSection('content'); ?>
    <div id="Result_Search">
        <div class="default_text_and_line_below">
            Результат поиска:
        </div>
        <script>
            var SearchPastes = JSON.parse('<?php echo $searh_pastes;?>');
            view_result_search();
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Baren\Downloads\OSPanel\domains\pastebinbarenad\resources\views/search_pastes.blade.php ENDPATH**/ ?>